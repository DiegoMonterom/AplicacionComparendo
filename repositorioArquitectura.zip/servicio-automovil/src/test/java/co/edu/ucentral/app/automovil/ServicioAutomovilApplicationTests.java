package co.edu.ucentral.app.automovil;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicioAutomovilApplicationTests {

	@Test
	void contextLoads() {
	}

}
